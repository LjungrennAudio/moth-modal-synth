// Copyright 2014 Emilie Gillet.
//
// Author: Emilie Gillet (emilie.o.gillet@gmail.com)
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in
// all copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
// THE SOFTWARE.
// 
// See http://creativecommons.org/licenses/MIT/ for more information.
//
// -----------------------------------------------------------------------------
//
// Patch parameters.

#ifndef ELEMENTS_DSP_PATCH_H_
#define ELEMENTS_DSP_PATCH_H_

namespace elements {

struct Patch {
  float exciter_envelope_shape;
  float exciter_bow_level;
  float exciter_bow_timbre;
  float exciter_blow_level;
  float exciter_blow_meta;
  float exciter_blow_timbre;
  float exciter_strike_level;
  float exciter_strike_meta;
  float exciter_strike_timbre;
  float exciter_signature;
  float resonator_geometry;
  float resonator_brightness;
  float resonator_damping;
  float resonator_position;
  float resonator_modulation_frequency;
  float resonator_modulation_offset;
  float reverb_diffusion;
  float reverb_lp;
  float space;
  
  float modulation_frequency;
};

}  // namespace elements

#endif  // ELEMENTS_DSP_PATCH_H_
